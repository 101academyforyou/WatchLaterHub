//! TODO 清單：頂列「TODO」按鈕打開的下拉清單，存在 chrome.storage

use serde::{Deserialize, Serialize};

pub const KEY: &str = "todos";

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq)]
pub struct Todo {
    pub id: String,
    pub text: String,
    #[serde(default)]
    pub done: bool,
    /// 提醒時間（毫秒時間戳）
    #[serde(rename = "remindAt", default, skip_serializing_if = "Option::is_none")]
    pub remind_at: Option<f64>,
    /// 這次的提醒已經跳出過了
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub notified: bool,
    /// 提醒時也寄信到使用者的 Gmail
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub email: bool,
    /// 這次提醒的寄信結果："ok" 或錯誤訊息
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mailed: Option<String>,
    /// 優先順序："high"／"mid"／"low"
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub priority: Option<String>,
}

/// 優先順序：(值, 圓點, 名稱)
pub const PRIORITIES: [(&str, &str, &str); 3] = [("high", "🔴", "高優先"), ("mid", "🟡", "中優先"), ("low", "🟢", "低優先")];

fn priority_info(p: &str) -> Option<(&'static str, &'static str, &'static str)> {
    PRIORITIES.iter().copied().find(|(v, _, _)| *v == p)
}

/// 提醒用的 alarm／通知名稱前綴
pub const ALARM_PREFIX: &str = "todo:";

// ---------- 純邏輯（可在本機 cargo test） ----------

/// 新增一項（空白不加）。回傳是否有加入
pub fn add(list: &mut Vec<Todo>, text: &str, id: String) -> bool {
    let text = text.trim();
    if text.is_empty() {
        return false;
    }
    list.push(Todo { id, text: text.to_string(), done: false, remind_at: None, notified: false, email: false, mailed: None, priority: None });
    true
}

pub fn toggle(list: &mut [Todo], id: &str) {
    if let Some(t) = list.iter_mut().find(|t| t.id == id) {
        t.done = !t.done;
    }
}

/// 改文字；改成空白就刪除
pub fn edit(list: &mut Vec<Todo>, id: &str, text: &str) {
    let text = text.trim();
    if text.is_empty() {
        return remove(list, id);
    }
    if let Some(t) = list.iter_mut().find(|t| t.id == id) {
        t.text = text.to_string();
    }
}

pub fn remove(list: &mut Vec<Todo>, id: &str) {
    list.retain(|t| t.id != id);
}

pub fn clear_done(list: &mut Vec<Todo>) {
    list.retain(|t| !t.done);
}

/// 拖曳排序
pub fn reorder(list: &mut Vec<Todo>, from: &str, to: &str, after: bool) {
    crate::videos::move_by_key(list, |t| t.id.as_str(), from, to, after);
}

/// 設定或清除提醒時間（重新設定後會再提醒一次）
pub fn set_remind(list: &mut [Todo], id: &str, at: Option<f64>) {
    if let Some(t) = list.iter_mut().find(|t| t.id == id) {
        t.remind_at = at;
        t.notified = false;
        t.mailed = None;
    }
}

/// 設定或清除優先順序（不認得的值當作清除）
pub fn set_priority(list: &mut [Todo], id: &str, p: Option<&str>) {
    if let Some(t) = list.iter_mut().find(|t| t.id == id) {
        t.priority = p.filter(|p| priority_info(p).is_some()).map(String::from);
    }
}

/// 提醒時要不要也寄信
pub fn set_email(list: &mut [Todo], id: &str, on: bool) {
    if let Some(t) = list.iter_mut().find(|t| t.id == id) {
        t.email = on;
    }
}

/// 提醒信的主旨與內文
pub fn mail_content(t: &Todo, when: &str) -> (String, String) {
    let short: String = t.text.chars().take(60).collect();
    let more = if t.text.chars().count() > 60 { "…" } else { "" };
    (
        format!("⏰ TODO 提醒：{short}{more}"),
        format!("{}\n\n提醒時間：{when}\n\n這封信是 WatchLaterHub 依照你設定的 TODO 提醒，用你的 Gmail 寄給你自己的。", t.text),
    )
}

/// 還沒提醒過、尚未完成的項目：(id, 提醒時間)
pub fn pending_reminders(list: &[Todo]) -> Vec<(String, f64)> {
    list.iter().filter(|t| !t.done && !t.notified).filter_map(|t| t.remind_at.map(|at| (t.id.clone(), at))).collect()
}

/// 時間到：標記為已提醒，回傳要顯示的項目（已完成、已提醒過或沒設時間就回傳 None）
pub fn take_due(list: &mut [Todo], id: &str) -> Option<Todo> {
    let t = list.iter_mut().find(|t| t.id == id && !t.done && !t.notified && t.remind_at.is_some())?;
    t.notified = true;
    Some(t.clone())
}

pub fn mark_done(list: &mut [Todo], id: &str) {
    if let Some(t) = list.iter_mut().find(|t| t.id == id) {
        t.done = true;
    }
}

/// 已過提醒時間、還沒完成
pub fn is_late(t: &Todo, now: f64) -> bool {
    !t.done && t.remind_at.is_some_and(|at| at <= now)
}

pub fn remaining(list: &[Todo]) -> usize {
    list.iter().filter(|t| !t.done).count()
}

/// 匯出 CSV（Excel 可直接開：開頭加 BOM、CRLF 換行）。`fmt_time` 把時間戳轉成文字
pub fn to_csv(list: &[Todo], fmt_time: impl Fn(f64) -> String) -> String {
    fn cell(s: &str) -> String {
        if s.contains([',', '"', '\n', '\r']) {
            format!("\"{}\"", s.replace('"', "\"\""))
        } else {
            s.to_string()
        }
    }
    let mut out = String::from("\u{feff}待辦事項,狀態,優先順序,提醒時間,寄信通知\r\n");
    for t in ordered(list) {
        let row = [
            cell(&t.text),
            (if t.done { "已完成" } else { "未完成" }).to_string(),
            t.priority.as_deref().and_then(priority_info).map(|(_, _, n)| n).unwrap_or_default().to_string(),
            t.remind_at.map(&fmt_time).unwrap_or_default(),
            (if t.email && t.remind_at.is_some() { "是" } else { "" }).to_string(),
        ];
        out.push_str(&row.join(","));
        out.push_str("\r\n");
    }
    out
}

/// 顯示順序：未完成在前、已完成在後，各自維持加入順序
pub fn ordered(list: &[Todo]) -> Vec<&Todo> {
    list.iter().filter(|t| !t.done).chain(list.iter().filter(|t| t.done)).collect()
}

// ---------- 提醒（在背景 service worker 執行，不碰 DOM） ----------

pub mod reminders {
    use super::*;
    use crate::chrome::{self, to_js};

    async fn load() -> Vec<Todo> {
        chrome::get_or(KEY, vec![]).await
    }

    async fn save(list: &[Todo]) {
        chrome::set(&[(KEY, to_js(list))]).await;
    }

    /// 依清單重設所有提醒鬧鐘（清單一改就呼叫）
    pub async fn sync_alarms() {
        for name in chrome::alarm_names().await {
            if name.starts_with(ALARM_PREFIX) {
                chrome::alarm_clear(&name).await;
            }
        }
        for (id, at) in pending_reminders(&load().await) {
            chrome::alarm_at(&format!("{ALARM_PREFIX}{id}"), at);
        }
    }

    /// 鬧鐘響了：跳出提醒小視窗
    pub async fn fire(id: &str) {
        let mut list = load().await;
        let Some(t) = take_due(&mut list, id) else { return };
        save(&list).await;
        if t.email {
            let (subject, body) = mail_content(&t, &super::view::when_label(t.remind_at.unwrap_or_else(chrome::now)));
            let result = match crate::gmail::send_to_self(&subject, &body).await {
                Ok(()) => "ok".to_string(),
                Err(e) => {
                    chrome::warn(&format!("WatchLaterHub mail failed: {e}"));
                    e
                }
            };
            let mut list = load().await;
            if let Some(x) = list.iter_mut().find(|x| x.id == id) {
                x.mailed = Some(result);
            }
            save(&list).await;
        }
        chrome::open_popup_window(&format!("reminder.html?id={}", js_sys::encode_uri_component(id)), 440, 360).await;
    }

    /// 提醒視窗上的「完成」
    pub async fn done(id: &str) {
        let mut list = load().await;
        mark_done(&mut list, id);
        save(&list).await;
    }

    /// 提醒視窗上的「稍後提醒」
    pub async fn snooze(id: &str, minutes: f64) {
        let mut list = load().await;
        set_remind(&mut list, id, Some(chrome::now() + minutes * 60_000.0));
        save(&list).await;
    }

    pub async fn get(id: &str) -> Option<Todo> {
        load().await.into_iter().find(|t| t.id == id)
    }
}

// ---------- 畫面 ----------

pub(crate) mod view {
    use super::*;
    use crate::chrome::{self, to_js};
    use crate::ui::{doc, el, hide, listen, on_click, spawn};
    use wasm_bindgen::prelude::*;
    use wasm_bindgen::JsCast;
    use web_sys::{Element, HtmlButtonElement, HtmlElement, HtmlInputElement, KeyboardEvent};

    async fn load() -> Vec<Todo> {
        chrome::get_or(KEY, vec![]).await
    }

    async fn save(list: &[Todo]) {
        chrome::set(&[(KEY, to_js(list))]).await;
    }

    /// 讀出 → 修改 → 存回 → 重畫
    fn update(f: impl FnOnce(&mut Vec<Todo>) + 'static) {
        spawn(async move {
            let mut list = load().await;
            f(&mut list);
            save(&list).await;
            render_list(&list);
        });
    }

    fn new_id() -> String {
        format!("{:x}{:04x}", chrome::now() as u64, (js_sys::Math::random() * 65536.0) as u32)
    }

    fn input(id: &str) -> HtmlInputElement {
        el(id).unchecked_into()
    }

    fn render_list(list: &[Todo]) {
        let n = remaining(list);
        el("todo-count").set_text_content(Some(&if n > 0 { format!("({n})") } else { String::new() }));
        let done = list.len() - n;
        el("todo-summary").set_text_content(Some(&if list.is_empty() {
            String::new()
        } else {
            format!("剩 {n} 項 · 已完成 {done} 項")
        }));
        el("todo-clear").unchecked_into::<HtmlButtonElement>().set_disabled(done == 0);
        el("todo-export").unchecked_into::<HtmlButtonElement>().set_disabled(list.is_empty());
        hide("todo-foot", list.is_empty());

        let ul = el("todo-list");
        ul.set_inner_html("");
        if list.is_empty() {
            ul.set_inner_html(r#"<li class="todo-none">還沒有待辦事項，在上面輸入後按 Enter</li>"#);
            return;
        }
        let q = crate::ui::search_text("todo-search");
        let shown: Vec<&Todo> = ordered(list).into_iter().filter(|t| crate::videos::matches(&q, &[&t.text])).collect();
        if shown.is_empty() {
            ul.set_inner_html(r#"<li class="todo-none">找不到符合的待辦事項</li>"#);
            return;
        }
        for t in shown {
            ul.append_child(&make_item(t)).unwrap();
        }
    }

    fn make_item(t: &Todo) -> Element {
        let li = doc().create_element("li").unwrap();
        li.set_class_name(if t.done { "todo-item done" } else { "todo-item" });
        li.set_inner_html(
            r#"<input type="checkbox"><div class="todo-body"><span class="todo-text" title="點兩下編輯"></span></div><span class="todo-prios" role="radiogroup" aria-label="優先順序"></span><button class="todo-alarm" type="button" title="設定提醒時間">⏰</button><button class="bm-del" type="button" title="刪除">✕</button>"#,
        );
        // 優先順序：三個圓點直接排在 ⏰ 左邊，點一下選定，再點一次取消
        {
            // 結構：<span.todo-prios><span.prio-others>沒選的…</span>選中的</span>
            // 選中的固定緊貼 ⏰；沒選的浮在左邊、滑鼠移上去才出現（不佔位置，文字不會被擠）
            let box_ = li.query_selector(".todo-prios").unwrap().unwrap();
            let others = doc().create_element("span").unwrap();
            others.set_class_name("prio-others");
            box_.append_child(&others).unwrap();
            for (v, dot, name) in PRIORITIES {
                let on = t.priority.as_deref() == Some(v);
                let b = doc().create_element("button").unwrap();
                b.set_class_name(if on { "todo-prio on" } else { "todo-prio" });
                let _ = b.set_attribute("type", "button");
                let _ = b.set_attribute("role", "radio");
                let _ = b.set_attribute("aria-checked", if on { "true" } else { "false" });
                let _ = b.set_attribute("title", &if on { "再點一下取消".to_string() } else { format!("設為{name}") });
                let _ = b.set_attribute("aria-label", name);
                b.set_text_content(Some(&format!("{dot} {name}")));
                let id = t.id.clone();
                listen(&b, "click", move |e| {
                    e.stop_propagation();
                    let id = id.clone();
                    update(move |l| set_priority(l, &id, if on { None } else { Some(v) }));
                });
                if on { box_.append_child(&b).unwrap() } else { others.append_child(&b).unwrap() };
            }
            if let Some(v) = t.priority.as_deref().filter(|p| priority_info(p).is_some()) {
                let _ = li.class_list().add_1(&format!("prio-{v}"));
                let _ = li.class_list().add_1("has-prio");
            }
        }
        if let Some(at) = t.remind_at {
            // 提醒時間標籤，點它也能改時間
            let chip = doc().create_element("button").unwrap();
            let late = is_late(t, chrome::now());
            chip.set_class_name(if late { "todo-when late" } else { "todo-when" });
            let _ = chip.set_attribute("type", "button");
            let _ = chip.set_attribute("title", "修改提醒時間");
            chip.set_text_content(Some(&format!(
                "⏰ {}{}{}",
                when_label(at),
                if t.email { " · 📧" } else { "" },
                if late { " · 已到期" } else { "" }
            )));
            li.query_selector(".todo-body").unwrap().unwrap().append_child(&chip).unwrap();
            let (li2, id, at2, em) = (li.clone(), t.id.clone(), t.remind_at, t.email);
            listen(&chip, "click", move |_| toggle_picker(&li2, id.clone(), at2, em));
            let _ = li.class_list().add_1("has-alarm");
        }
        {
            let (li2, id, at, em) = (li.clone(), t.id.clone(), t.remind_at, t.email);
            listen(&li.query_selector(".todo-alarm").unwrap().unwrap(), "click", move |_| {
                toggle_picker(&li2, id.clone(), at, em)
            });
        }
        li.prepend_with_node_1(&crate::drag::grip()).unwrap();
        crate::drag::sortable(
            crate::drag::Sortable {
                item: li.clone(),
                handle: Some(li.clone()),
                zone: li.clone(),
                group: "todo",
                id: t.id.clone(),
                can_contain: false,
            },
            std::rc::Rc::new(|from, to, pos| {
                update(move |l| reorder(l, &from, &to, pos == crate::drag::Pos::After));
            }),
        );
        let cb: HtmlInputElement = li.query_selector("input").unwrap().unwrap().unchecked_into();
        cb.set_checked(t.done);
        let _ = cb.set_attribute("aria-label", &format!("完成：{}", t.text));
        let span = li.query_selector(".todo-text").unwrap().unwrap();
        span.set_text_content(Some(&t.text));

        let id = t.id.clone();
        listen(&cb, "change", move |_| {
            let id = id.clone();
            update(move |l| toggle(l, &id));
        });
        let id = t.id.clone();
        listen(&li.query_selector(".bm-del").unwrap().unwrap(), "click", move |_| {
            let id = id.clone();
            update(move |l| remove(l, &id));
        });
        let (id, text, span2) = (t.id.clone(), t.text.clone(), span.clone());
        listen(&span, "dblclick", move |_| start_edit(&span2, id.clone(), text.clone()));
        li
    }

    // ---------- 提醒時間 ----------

    fn date_of(ms: f64) -> js_sys::Date {
        js_sys::Date::new(&JsValue::from_f64(ms))
    }

    /// 本地時間的「年月日」序號，用來判斷今天／明天
    fn day_key(d: &js_sys::Date) -> (u32, u32, u32) {
        (d.get_full_year(), d.get_month(), d.get_date())
    }

    /// 「今天 14:30」「明天 09:00」「10/5 (週日) 14:30」
    pub(crate) fn when_label(ms: f64) -> String {
        let d = date_of(ms);
        let now = chrome::now();
        let hm = format!("{:02}:{:02}", d.get_hours(), d.get_minutes());
        let day = if day_key(&d) == day_key(&date_of(now)) {
            "今天".to_string()
        } else if day_key(&d) == day_key(&date_of(now + 86_400_000.0)) {
            "明天".to_string()
        } else if day_key(&d) == day_key(&date_of(now - 86_400_000.0)) {
            "昨天".to_string()
        } else {
            let wd = ["日", "一", "二", "三", "四", "五", "六"][d.get_day() as usize];
            let year = if d.get_full_year() != date_of(now).get_full_year() { format!("{}/", d.get_full_year()) } else { String::new() };
            format!("{year}{}/{} (週{wd})", d.get_month() + 1, d.get_date())
        };
        format!("{day} {hm}")
    }

    /// <input type="datetime-local"> 的值（本地時間 YYYY-MM-DDTHH:MM）
    fn to_local_input(ms: f64) -> String {
        let d = date_of(ms);
        format!(
            "{:04}-{:02}-{:02}T{:02}:{:02}",
            d.get_full_year(),
            d.get_month() + 1,
            d.get_date(),
            d.get_hours(),
            d.get_minutes()
        )
    }

    fn from_local_input(v: &str) -> Option<f64> {
        if v.is_empty() {
            return None;
        }
        // 沒有時區的日期時間字串，瀏覽器會當成本地時間
        let t = js_sys::Date::new(&JsValue::from_str(v)).get_time();
        (!t.is_nan()).then_some(t)
    }

    /// 某天幾點（day_offset：0 今天、1 明天）
    fn at_hour(day_offset: f64, hour: u32) -> f64 {
        let d = date_of(chrome::now() + day_offset * 86_400_000.0);
        d.set_hours(hour);
        d.set_minutes(0);
        d.set_seconds(0);
        d.set_milliseconds(0);
        d.get_time()
    }

    /// 在項目下方展開／收起時間選擇器
    fn toggle_picker(li: &Element, id: String, current: Option<f64>, email: bool) {
        if let Some(old) = li.query_selector(".todo-picker").ok().flatten() {
            old.remove();
            return;
        }
        // 一次只開一個
        if let Ok(others) = doc().query_selector_all("#todo-list .todo-picker") {
            for i in 0..others.length() {
                if let Some(n) = others.item(i) {
                    n.unchecked_into::<Element>().remove();
                }
            }
        }
        let now = chrome::now();
        let quick: [(&str, f64); 3] =
            [("10 分鐘後", now + 600_000.0), ("30 分鐘後", now + 1_800_000.0), ("明天 09:00", at_hour(1.0, 9))];

        let p = doc().create_element("div").unwrap();
        p.set_class_name("todo-picker");
        p.set_inner_html(
            r#"<div class="todo-quick"></div><div class="todo-pick-row"><input type="datetime-local" class="todo-dt" aria-label="提醒時間"><button class="btn primary todo-set" type="button">設定</button><button class="btn todo-unset" type="button">取消提醒</button></div><div class="todo-mail"><label><input type="checkbox" class="todo-mail-cb"> 同時寄信到我的 Gmail</label><span class="todo-mail-who"></span><button class="todo-mail-switch" type="button" hidden>換帳號</button></div><div class="todo-pick-msg"></div>"#,
        );
        let q = p.query_selector(".todo-quick").unwrap().unwrap();
        for (label, at) in quick {
            let b = doc().create_element("button").unwrap();
            b.set_class_name("chip");
            let _ = b.set_attribute("type", "button");
            b.set_text_content(Some(label));
            let id = id.clone();
            listen(&b, "click", move |_| {
                let id = id.clone();
                update(move |l| set_remind(l, &id, Some(at)));
            });
            q.append_child(&b).unwrap();
        }
        let dt: HtmlInputElement = p.query_selector(".todo-dt").unwrap().unwrap().unchecked_into();
        dt.set_value(&to_local_input(current.unwrap_or(now + 3_600_000.0)));
        dt.set_min(&to_local_input(now));
        setup_mail_row(&p, id.clone(), email);
        let unset = p.query_selector(".todo-unset").unwrap().unwrap();
        unset.unchecked_ref::<HtmlElement>().set_hidden(current.is_none());

        let set = {
            let (id, dt, p2) = (id.clone(), dt.clone(), p.clone());
            move || match from_local_input(&dt.value()) {
                Some(at) if at > chrome::now() => {
                    let id = id.clone();
                    update(move |l| set_remind(l, &id, Some(at)));
                }
                Some(_) => text_in(&p2, ".todo-pick-msg", "請選擇未來的時間"),
                None => text_in(&p2, ".todo-pick-msg", "請選擇日期和時間"),
            }
        };
        let set = std::rc::Rc::new(set);
        {
            let set = set.clone();
            listen(&p.query_selector(".todo-set").unwrap().unwrap(), "click", move |_| set());
        }
        listen(&dt, "keydown", move |e| {
            let k: &KeyboardEvent = e.unchecked_ref();
            if k.key() == "Enter" {
                e.prevent_default();
                set();
            }
        });
        listen(&unset, "click", move |_| {
            let id = id.clone();
            update(move |l| set_remind(l, &id, None));
        });
        // 選擇器裡的操作不要觸發拖曳
        let _ = li.set_attribute("draggable", "false");
        li.append_child(&p).unwrap();
        let _ = dt.unchecked_ref::<HtmlElement>().focus();
    }

    /// 只改資料、不重畫（避免選擇器被收起來）
    fn update_quiet(f: impl FnOnce(&mut Vec<Todo>) + 'static) {
        spawn(async move {
            let mut list = load().await;
            f(&mut list);
            save(&list).await;
        });
    }

    /// 選擇器裡的「📧 同時寄信到我的 Gmail」
    fn setup_mail_row(p: &Element, id: String, email: bool) {
        let cb: HtmlInputElement = p.query_selector(".todo-mail-cb").unwrap().unwrap().unchecked_into();
        cb.set_checked(email);
        let who = p.query_selector(".todo-mail-who").unwrap().unwrap();
        let switch: HtmlElement = p.query_selector(".todo-mail-switch").unwrap().unwrap().unchecked_into();
        let show_who = {
            let (who, switch) = (who.clone(), switch.clone());
            move |addr: Option<String>| {
                who.set_text_content(Some(&addr.as_ref().map(|a| format!("（寄到 {a}）")).unwrap_or_default()));
                switch.set_hidden(addr.is_none());
            }
        };
        {
            let show_who = show_who.clone();
            spawn(async move { show_who(crate::gmail::email().await) });
        }
        // 第一次勾選或按「換帳號」：跳出 Google 授權畫面
        let connect = {
            let (p, show_who) = (p.clone(), show_who.clone());
            move |force: bool, cb: HtmlInputElement, id: String| {
                let (p, show_who) = (p.clone(), show_who.clone());
                spawn(async move {
                    let addr = match crate::gmail::email().await {
                        Some(a) if !force => Ok(a),
                        _ => {
                            text_in(&p, ".todo-pick-msg", "請在跳出的 Google 視窗中選擇帳號並允許寄信…");
                            crate::gmail::connect().await
                        }
                    };
                    match addr {
                        Ok(a) => {
                            text_in(&p, ".todo-pick-msg", "");
                            show_who(Some(a));
                            update_quiet(move |l| set_email(l, &id, true));
                        }
                        Err(e) => {
                            cb.set_checked(false);
                            let hint = if e.contains("could not be loaded") || e.contains("登入失敗") {
                                format!("無法授權寄信：{e}（請確認 Google Cloud 已啟用 Gmail API，並在 OAuth 同意畫面加入 gmail.send 權限）")
                            } else {
                                format!("無法授權寄信：{e}")
                            };
                            text_in(&p, ".todo-pick-msg", &hint);
                        }
                    }
                });
            }
        };
        let connect = std::rc::Rc::new(connect);
        {
            let (cb2, id, connect) = (cb.clone(), id.clone(), connect.clone());
            listen(&cb, "change", move |_| {
                if cb2.checked() {
                    connect(false, cb2.clone(), id.clone());
                } else {
                    let id = id.clone();
                    update_quiet(move |l| set_email(l, &id, false));
                }
            });
        }
        listen(&switch, "click", move |_| {
            cb.set_checked(true);
            connect(true, cb.clone(), id.clone());
        });
    }

    fn text_in(parent: &Element, sel: &str, s: &str) {
        if let Some(e) = parent.query_selector(sel).ok().flatten() {
            e.set_text_content(Some(s));
        }
    }

    /// 點兩下文字：原地改成輸入框；Enter 或離開儲存、Esc 取消
    fn start_edit(span: &Element, id: String, text: String) {
        let inp: HtmlInputElement = doc().create_element("input").unwrap().unchecked_into();
        inp.set_class_name("todo-edit");
        inp.set_value(&text);
        // 編輯時暫停拖曳，才能用滑鼠選取文字
        if let Some(li) = span.closest("li").ok().flatten() {
            let _ = li.set_attribute("draggable", "false");
        }
        let _ = span.replace_with_with_node_1(&inp);
        let _ = inp.focus();
        inp.select();

        let finished = std::rc::Rc::new(std::cell::Cell::new(false));
        let (f1, i1, id1) = (finished.clone(), inp.clone(), id.clone());
        listen(&inp, "keydown", move |e| {
            let k: &KeyboardEvent = e.unchecked_ref();
            if k.is_composing() {
                return;
            }
            match k.key().as_str() {
                "Enter" => {
                    f1.set(true);
                    let (id, v) = (id1.clone(), i1.value());
                    update(move |l| edit(l, &id, &v));
                }
                "Escape" => {
                    e.stop_propagation(); // 不要順便關掉整個清單
                    f1.set(true);
                    spawn(async { render_list(&load().await) });
                }
                _ => {}
            }
        });
        let i2 = inp.clone();
        listen(&inp, "blur", move |_| {
            if !finished.get() {
                finished.set(true);
                let (id, v) = (id.clone(), i2.value());
                update(move |l| edit(l, &id, &v));
            }
        });
    }

    fn is_open() -> bool {
        !el("todo").hidden()
    }

    /// 被別的面板打開時關掉自己
    pub fn close() {
        if is_open() {
            set_open(false);
        }
    }

    fn set_open(open: bool) {
        if open {
            crate::ui::close_panels_except("todo");
        }
        hide("todo", !open);
        let _ = el("todo-toggle").class_list().toggle_with_force("on", open);
        let _ = el("todo-toggle").set_attribute("aria-expanded", if open { "true" } else { "false" });
        if open {
            let _ = el("todo-input").focus();
            // 重畫一次，讓「已到期」標示是最新的
            spawn(async { render_list(&load().await) });
        }
    }

    fn add_from_input() {
        let v = input("todo-input").value();
        if v.trim().is_empty() {
            return;
        }
        input("todo-input").set_value("");
        update(move |l| {
            add(l, &v, new_id());
        });
    }

    pub fn start() {
        on_click("todo-toggle", || set_open(!is_open()));
        on_click("todo-close", || set_open(false));
        on_click("todo-add", add_from_input);
        on_click("todo-clear", || update(clear_done));
        on_click("todo-export", || {
            spawn(async {
                let list = load().await;
                let csv = to_csv(&list, |ms| to_local_input(ms).replace('T', " "));
                let name = format!("TODO-{}.csv", to_local_input(chrome::now()).split('T').next().unwrap_or("").replace('-', ""));
                crate::ui::download_text(&name, &csv, "text/csv;charset=utf-8");
            })
        });
        crate::ui::search_box("todo-search", || spawn(async { render_list(&load().await) }));
        listen(&el("todo-input"), "keydown", |e| {
            let k: &KeyboardEvent = e.unchecked_ref();
            if k.key() == "Enter" && !k.is_composing() {
                e.prevent_default();
                add_from_input();
            }
        });

        // 點清單外面或按 Esc 關閉
        let d: web_sys::EventTarget = doc().into();
        listen(&d, "mousedown", |e| {
            if !is_open() {
                return;
            }
            let inside = e
                .target()
                .and_then(|t| t.dyn_into::<web_sys::Node>().ok())
                .map(|n| el("todo").contains(Some(&n)) || el("todo-toggle").contains(Some(&n)))
                .unwrap_or(false);
            if !inside {
                set_open(false);
            }
        });
        listen(&d, "keydown", |e| {
            if is_open() && e.unchecked_ref::<KeyboardEvent>().key() == "Escape" {
                set_open(false);
                let _ = el("todo-toggle").focus();
            }
        });

        // 其他分頁改了清單時同步更新（正在編輯時不打斷）
        let cb = Closure::<dyn FnMut(JsValue, JsValue)>::new(|changes: JsValue, _area: JsValue| {
            if js_sys::Reflect::has(&changes, &KEY.into()).unwrap_or(false)
                && doc().query_selector("#todo-list .todo-edit, #todo-list .todo-picker").ok().flatten().is_none()
            {
                spawn(async { render_list(&load().await) });
            }
        });
        chrome::on_storage_changed(&cb);
        cb.forget();

        spawn(async { render_list(&load().await) });

        // 從提醒通知點進來（newtab.html#todo）：直接打開清單
        let loc = web_sys::window().unwrap().location();
        if loc.hash().unwrap_or_default() == "#todo" {
            let _ = web_sys::window().unwrap().history().and_then(|h| h.replace_state_with_url(&JsValue::NULL, "", Some("newtab.html")));
            set_open(true);
        }
    }
}

pub use view::{close, start};

#[cfg(test)]
mod tests {
    use super::*;

    fn ids(v: &[&Todo]) -> Vec<String> {
        v.iter().map(|t| t.id.clone()).collect()
    }

    #[test]
    fn add_toggle_edit_remove() {
        let mut l = vec![];
        assert!(add(&mut l, "  買牛奶 ", "a".into()));
        assert!(l[0].remind_at.is_none());
        assert!(!add(&mut l, "   ", "x".into()));
        add(&mut l, "寫論文", "b".into());
        add(&mut l, "回信", "c".into());
        assert_eq!(l[0].text, "買牛奶");
        assert_eq!(remaining(&l), 3);

        toggle(&mut l, "a");
        assert_eq!(remaining(&l), 2);
        assert_eq!(ids(&ordered(&l)), ["b", "c", "a"]);

        edit(&mut l, "b", " 寫論文第三章 ");
        assert_eq!(l[1].text, "寫論文第三章");
        edit(&mut l, "c", "  ");
        assert_eq!(l.len(), 2);

        clear_done(&mut l);
        assert_eq!(ids(&ordered(&l)), ["b"]);
        remove(&mut l, "b");
        assert!(l.is_empty());
    }

    #[test]
    fn reminders_flow() {
        let mut l = vec![];
        add(&mut l, "開會", "a".into());
        add(&mut l, "繳費", "b".into());
        add(&mut l, "看書", "c".into());
        set_remind(&mut l, "a", Some(1000.0));
        set_remind(&mut l, "b", Some(2000.0));
        toggle(&mut l, "b"); // 已完成的不提醒
        assert_eq!(pending_reminders(&l), vec![("a".to_string(), 1000.0)]);
        assert!(is_late(&l[0], 1000.0) && !is_late(&l[0], 999.0));
        assert!(!is_late(&l[1], 5000.0) && !is_late(&l[2], 5000.0));

        // 時間到只提醒一次
        assert_eq!(take_due(&mut l, "a").map(|t| t.text), Some("開會".to_string()));
        assert!(take_due(&mut l, "a").is_none());
        assert!(take_due(&mut l, "c").is_none());
        assert!(pending_reminders(&l).is_empty());

        // 重新設定（稍後提醒）會再提醒
        set_remind(&mut l, "a", Some(3000.0));
        assert_eq!(pending_reminders(&l), vec![("a".to_string(), 3000.0)]);
        mark_done(&mut l, "a");
        assert!(pending_reminders(&l).is_empty());
        set_remind(&mut l, "c", None);
        assert!(l[2].remind_at.is_none());

        // 寄信設定；重設時間會清掉上次的寄信結果
        set_email(&mut l, "c", true);
        l[2].mailed = Some("ok".into());
        set_remind(&mut l, "c", Some(9000.0));
        assert!(l[2].email && l[2].mailed.is_none());
        let (subj, body) = mail_content(&l[2], "今天 09:00");
        assert_eq!(subj, "⏰ TODO 提醒：看書");
        assert!(body.starts_with("看書\n\n提醒時間：今天 09:00"));
        let long = Todo { text: "字".repeat(80), ..l[2].clone() };
        assert_eq!(mail_content(&long, "x").0.chars().count(), "⏰ TODO 提醒：".chars().count() + 61);

        // 匯出 CSV：逗號、引號、換行要跳脫；未完成排前面
        let mut c = vec![];
        add(&mut c, "買牛奶, 蛋", "1".into());
        add(&mut c, "說\"嗨\"", "2".into());
        toggle(&mut c, "1");
        set_remind(&mut c, "2", Some(5.0));
        set_email(&mut c, "2", true);
        set_priority(&mut c, "2", Some("high"));
        set_priority(&mut c, "1", Some("bogus"));
        assert!(c[0].priority.is_none());
        let csv = to_csv(&c, |ms| format!("T{ms}"));
        assert_eq!(
            csv,
            "\u{feff}待辦事項,狀態,優先順序,提醒時間,寄信通知\r\n\"說\"\"嗨\"\"\",未完成,高優先,T5,是\r\n\"買牛奶, 蛋\",已完成,,,\r\n"
        );

        // 舊資料（沒有提醒欄位）讀得進來，沒設提醒時存檔也不多欄位
        let old: Todo = serde_json::from_str(r#"{"id":"x","text":"t","done":false}"#).unwrap();
        assert_eq!(serde_json::to_string(&old).unwrap(), r#"{"id":"x","text":"t","done":false}"#);
    }
}
