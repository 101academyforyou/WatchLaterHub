//! 「開啟」：加入電腦上的軟體，點一下就開啟
//!
//! - 電腦上的軟體：透過「電腦小幫手」（launcher/，Chrome Native Messaging）開啟；要先執行 ./install-launcher.sh
//! - 有專屬網址的軟體（vscode://、slack:// …）：不用小幫手，直接用網址開啟

use serde::{Deserialize, Serialize};

pub const KEY: &str = "apps";
pub const HOST: &str = "com.watchlaterhub.launcher";

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq)]
pub struct AppEntry {
    pub id: String,
    pub name: String,
    /// "app"：電腦上的軟體（target = 路徑）；"url"：用網址開啟（target = 網址）
    pub kind: String,
    pub target: String,
    /// 圖示用的官網網域（快速加入的軟體才有）
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub icon: Option<String>,
}

#[derive(Deserialize, Clone, Debug, PartialEq)]
pub struct Installed {
    pub name: String,
    pub path: String,
}

/// macOS「終端機」的位置（Terminal 沒有專屬網址，要透過小幫手開啟）
pub const TERMINAL_MAC: &str = "/System/Applications/Utilities/Terminal.app";

/// 快速加入的軟體
pub struct Preset {
    pub name: &'static str,
    /// 圖示：官網網域（用 Google 的網站圖示服務取得各軟體官網的 favicon）；空字串 = 用「>_」
    pub icon: &'static str,
    /// 電腦上的軟體名稱（有裝桌面版就透過小幫手開啟）
    pub apps: &'static [&'static str],
    /// 沒裝桌面版時的開啟方式：專屬網址或網頁
    pub url: &'static str,
}

pub const PRESETS: [Preset; 13] = [
    Preset { name: "Terminal", icon: "", apps: &["Terminal", "終端機", "GNOME Terminal", "Konsole"], url: "" },
    Preset { name: "Claude", icon: "claude.ai", apps: &["Claude"], url: "https://claude.ai/" },
    Preset { name: "ChatGPT", icon: "chatgpt.com", apps: &["ChatGPT"], url: "https://chatgpt.com/" },
    Preset { name: "Gemini", icon: "gemini.google.com", apps: &["Gemini"], url: "https://gemini.google.com/" },
    Preset { name: "VS Code", icon: "code.visualstudio.com", apps: &["Visual Studio Code", "Code"], url: "vscode://" },
    Preset { name: "Obsidian", icon: "obsidian.md", apps: &["Obsidian"], url: "obsidian://" },
    Preset { name: "Notion", icon: "notion.so", apps: &["Notion"], url: "notion://" },
    Preset { name: "Discord", icon: "discord.com", apps: &["Discord"], url: "discord://" },
    Preset { name: "Slack", icon: "slack.com", apps: &["Slack"], url: "slack://open" },
    Preset { name: "Google Meet", icon: "meet.google.com", apps: &[], url: "https://meet.google.com/" },
    Preset { name: "Zoom", icon: "zoom.us", apps: &["zoom.us", "Zoom", "Zoom Workplace"], url: "zoommtg://" },
    Preset { name: "Teams", icon: "teams.microsoft.com", apps: &["Microsoft Teams", "Microsoft Teams (work or school)", "Microsoft Teams classic"], url: "msteams:" },
    Preset { name: "Spotify", icon: "open.spotify.com", apps: &["Spotify"], url: "spotify:" },
];

/// 網站圖示網址
pub fn icon_url(domain: &str) -> String {
    format!("https://www.google.com/s2/favicons?domain={domain}&sz=64")
}

/// 快速加入：有裝桌面版 → (app, 路徑)；否則 → (url, 網址)；都沒有（終端機沒裝小幫手）→ macOS 的終端機路徑
pub fn resolve_preset(p: &Preset, installed: Option<&[Installed]>) -> (&'static str, String) {
    if let Some(list) = installed {
        for want in p.apps {
            if let Some(a) = list.iter().find(|a| a.name.eq_ignore_ascii_case(want)) {
                return ("app", a.path.clone());
            }
        }
    }
    if p.url.is_empty() {
        ("app", TERMINAL_MAC.to_string())
    } else {
        ("url", p.url.to_string())
    }
}

// ---------- 純邏輯（可在本機 cargo test） ----------

/// 網址要有通訊協定（vscode:、https: …）；不能是 javascript: 這類
pub fn valid_url(u: &str) -> bool {
    let u = u.trim();
    let Some((scheme, _)) = u.split_once(':') else { return false };
    !scheme.is_empty()
        && scheme.chars().next().is_some_and(|c| c.is_ascii_alphabetic())
        && scheme.chars().all(|c| c.is_ascii_alphanumeric() || "+-.".contains(c))
        && !["javascript", "data", "file", "vbscript"].contains(&scheme.to_ascii_lowercase().as_str())
}

/// 加入一項；同一個目標不重複加。回傳是否有加入
pub fn add(list: &mut Vec<AppEntry>, name: &str, kind: &str, target: &str, id: String) -> bool {
    let (name, target) = (name.trim(), target.trim());
    if name.is_empty() || target.is_empty() || list.iter().any(|a| a.target == target) {
        return false;
    }
    if kind == "url" && !valid_url(target) {
        return false;
    }
    list.push(AppEntry { id, name: name.to_string(), kind: kind.to_string(), target: target.to_string(), icon: None });
    true
}

/// 加入快速加入的軟體（帶圖示）
pub fn add_preset(list: &mut Vec<AppEntry>, p: &Preset, installed: Option<&[Installed]>, id: String) -> bool {
    let (kind, target) = resolve_preset(p, installed);
    let ok = add(list, p.name, kind, &target, id.clone());
    if ok && !p.icon.is_empty() {
        if let Some(a) = list.iter_mut().find(|a| a.id == id) {
            a.icon = Some(p.icon.to_string());
        }
    }
    ok
}

pub fn remove(list: &mut Vec<AppEntry>, id: &str) {
    list.retain(|a| a.id != id);
}

pub fn reorder(list: &mut Vec<AppEntry>, from: &str, to: &str, after: bool) {
    crate::videos::move_by_key(list, |a| a.id.as_str(), from, to, after);
}

/// 圖示：名稱第一個字（英文大寫）＋依名稱固定的顏色
pub fn avatar(name: &str) -> (String, u32) {
    let first = name.trim().chars().next().map(|c| c.to_uppercase().collect::<String>()).unwrap_or_default();
    let hue = name.chars().fold(7u32, |h, c| h.wrapping_mul(31).wrapping_add(c as u32)) % 360;
    (first, hue)
}

// ---------- 畫面 ----------

mod view {
    use super::*;
    use crate::chrome::{self, to_js};
    use crate::drag::{Pos, Sortable};
    use crate::ui::{doc, el, hide, listen, on_click, spawn};
    use std::cell::RefCell;
    use std::rc::Rc;
    use wasm_bindgen::prelude::*;
    use wasm_bindgen::JsCast;
    use web_sys::{Element, HtmlInputElement, KeyboardEvent};

    #[wasm_bindgen]
    extern "C" {
        #[wasm_bindgen(js_namespace = ["chrome", "runtime"], js_name = sendNativeMessage, catch)]
        async fn send_native_raw(host: &str, msg: JsValue) -> Result<JsValue, JsValue>;
    }

    thread_local! {
        /// 小幫手回報的已安裝軟體（None = 小幫手沒裝或連不上）
        static INSTALLED: RefCell<Option<Vec<Installed>>> = const { RefCell::new(None) };
    }

    async fn native(msg: serde_json::Value) -> Result<serde_json::Value, String> {
        let r = send_native_raw(HOST, to_js(&msg)).await.map_err(chrome::err_msg)?;
        let v: serde_json::Value = chrome::from_js(&r).unwrap_or(serde_json::Value::Null);
        if v["ok"].as_bool() == Some(true) {
            Ok(v)
        } else {
            Err(v["error"].as_str().unwrap_or("小幫手沒有回應").to_string())
        }
    }

    async fn load() -> Vec<AppEntry> {
        chrome::get_or(KEY, vec![]).await
    }

    fn update(f: impl FnOnce(&mut Vec<AppEntry>) + 'static) {
        spawn(async move {
            let mut list = load().await;
            f(&mut list);
            chrome::set(&[(KEY, to_js(&list))]).await;
            render(&list);
            render_installed();
        });
    }

    fn new_id() -> String {
        format!("{:x}{:04x}", chrome::now() as u64, (js_sys::Math::random() * 65536.0) as u32)
    }

    fn status(msg: &str, error: bool) {
        let s = el("apps-status");
        s.set_text_content(Some(msg));
        let _ = s.class_list().toggle_with_force("err", error);
    }

    async fn launch(a: AppEntry) {
        if a.kind == "url" {
            chrome::open_in_this_tab(&a.target).await;
            return;
        }
        match native(serde_json::json!({ "action": "open", "path": a.target })).await {
            Ok(_) => status(&format!("已開啟「{}」", a.name), false),
            Err(e) if e.contains("not found") || e.contains("Specified native messaging host") => {
                status(&format!("無法開啟「{}」", a.name), true);
            }
            Err(e) => status(&format!("無法開啟「{}」：{e}", a.name), true),
        }
    }

    fn tile(a: &AppEntry) -> Element {
        let b = doc().create_element("div").unwrap();
        b.set_class_name("app-tile");
        let _ = b.set_attribute("role", "button");
        let _ = b.set_attribute("tabindex", "0");
        let _ = b.set_attribute("title", &format!("{}\n{}", a.name, if a.kind == "url" { a.target.as_str() } else { "電腦上的軟體" }));
        b.set_inner_html(r#"<span class="app-ico"></span><span class="app-name"></span><button class="bm-del" type="button" title="移除">✕</button>"#);
        let ico = b.query_selector(".app-ico").unwrap().unwrap();
        match (&a.icon, a.name.as_str()) {
            (Some(d), _) => {
                let _ = ico.class_list().add_1("logo");
                ico.set_inner_html(r#"<img alt="">"#);
                ico.query_selector("img").unwrap().unwrap().unchecked_into::<web_sys::HtmlImageElement>().set_src(&icon_url(d));
            }
            (None, "Terminal") => {
                let _ = ico.class_list().add_1("term");
                ico.set_text_content(Some(">_"));
            }
            _ => {
                let (letter, hue) = avatar(&a.name);
                ico.set_text_content(Some(&letter));
                let _ = ico.set_attribute("style", &format!("background: hsl({hue} 55% 46%)"));
            }
        }
        b.query_selector(".app-name").unwrap().unwrap().set_text_content(Some(&a.name));
        let item = a.clone();
        listen(&b, "click", move |_| {
            let item = item.clone();
            spawn(launch(item));
        });
        let item = a.clone();
        listen(&b, "keydown", move |e| {
            if e.unchecked_ref::<KeyboardEvent>().key() == "Enter" {
                let item = item.clone();
                spawn(launch(item));
            }
        });
        let id = a.id.clone();
        listen(&b.query_selector(".bm-del").unwrap().unwrap(), "click", move |e| {
            e.stop_propagation();
            let id = id.clone();
            update(move |l| remove(l, &id));
        });
        crate::drag::sortable(
            Sortable { item: b.clone(), handle: Some(b.clone()), zone: b.clone(), group: "apps", id: a.id.clone(), can_contain: false },
            Rc::new(|from, to, pos| update(move |l| reorder(l, &from, &to, pos == Pos::After))),
        );
        b
    }

    fn render(list: &[AppEntry]) {
        let grid = el("apps-grid");
        grid.set_inner_html("");
        if list.is_empty() {
            grid.set_inner_html(r#"<div class="todo-none">還沒有加入軟體，按右上「＋ 新增」</div>"#);
            return;
        }
        for a in list {
            grid.append_child(&tile(a)).unwrap();
        }
    }

    /// 新增區：小幫手回報的已安裝軟體（可搜尋，點一下加入）
    fn render_installed() {
        let added: Vec<String> = Vec::new();
        let box_ = el("apps-installed");
        let q = crate::ui::search_text("apps-search");
        spawn(async move {
            let mut added = added;
            added.extend(load().await.into_iter().map(|a| a.target));
            let installed = INSTALLED.with(|i| i.borrow().clone());
            box_.set_inner_html("");
            let Some(apps) = installed else { return };
            // 只在搜尋時列出符合的軟體
            if q.is_empty() {
                return;
            }
            let shown: Vec<&Installed> = apps.iter().filter(|a| crate::videos::matches(&q, &[&a.name])).take(30).collect();
            if shown.is_empty() {
                box_.set_inner_html(r#"<div class="todo-none">找不到符合的軟體</div>"#);
            }
            for a in shown {
                let b = doc().create_element("button").unwrap();
                b.set_class_name("app-pick");
                let _ = b.set_attribute("type", "button");
                let is_added = added.contains(&a.path);
                b.set_text_content(Some(&format!("{}{}", a.name, if is_added { "  ✓" } else { "" })));
                let _ = b.set_attribute("title", &a.path);
                if is_added {
                    let _ = b.class_list().add_1("on");
                }
                let (name, path) = (a.name.clone(), a.path.clone());
                listen(&b, "click", move |_| {
                    let (name, path) = (name.clone(), path.clone());
                    update(move |l| {
                        add(l, &name, "app", &path, new_id());
                    });
                });
                box_.append_child(&b).unwrap();
            }
        });
    }

    /// 檢查小幫手、取得已安裝軟體
    async fn check_helper() {
        match native(serde_json::json!({ "action": "list" })).await {
            Ok(v) => {
                let apps: Vec<Installed> = serde_json::from_value(v["apps"].clone()).unwrap_or_default();
                INSTALLED.with(|i| *i.borrow_mut() = Some(apps));
                hide("apps-helper-on", false);
                status("", false);
            }
            Err(_) => {
                INSTALLED.with(|i| *i.borrow_mut() = None);
                hide("apps-helper-on", true);
                status("", false);
            }
        }
        render_installed();
    }

    fn add_url_from_inputs() {
        let name: HtmlInputElement = el("apps-url-name").unchecked_into();
        let url: HtmlInputElement = el("apps-url").unchecked_into();
        let (n, u) = (name.value(), url.value());
        if !valid_url(&u) {
            status("網址要包含通訊協定，例如 vscode:// 或 https://", true);
            let _ = url.focus();
            return;
        }
        let n = if n.trim().is_empty() { u.clone() } else { n };
        name.set_value("");
        url.set_value("");
        update(move |l| {
            add(l, &n, "url", &u, new_id());
        });
    }

    fn is_open() -> bool {
        !el("apps").hidden()
    }

    fn set_open(open: bool) {
        if open {
            crate::ui::close_panels_except("apps");
        }
        hide("apps", !open);
        let _ = el("apps-toggle").class_list().toggle_with_force("on", open);
        let _ = el("apps-toggle").set_attribute("aria-expanded", if open { "true" } else { "false" });
        if open {
            spawn(async {
                let list = load().await;
                hide("apps-add", !list.is_empty());
                render(&list);
                check_helper().await;
            });
        }
    }

    pub fn close() {
        if is_open() {
            set_open(false);
        }
    }

    pub fn start() {
        on_click("apps-toggle", || set_open(!is_open()));
        on_click("apps-close", || set_open(false));
        on_click("apps-add-btn", || {
            let show = el("apps-add").hidden();
            hide("apps-add", !show);
        });
        on_click("apps-url-add", add_url_from_inputs);
        listen(&el("apps-url"), "keydown", |e| {
            let k: &KeyboardEvent = e.unchecked_ref();
            if k.key() == "Enter" && !k.is_composing() {
                add_url_from_inputs();
            }
        });
        crate::ui::search_box("apps-search", render_installed);
        // 快速加入（有裝桌面版就用桌面版，否則用專屬網址或網頁）
        let presets = el("apps-presets");
        for (i, p) in PRESETS.iter().enumerate() {
            let b = doc().create_element("button").unwrap();
            b.set_class_name("chip preset");
            let _ = b.set_attribute("type", "button");
            b.set_inner_html(r#"<span class="plus">＋</span><span class="pico"></span><span class="pname"></span>"#);
            let pico = b.query_selector(".pico").unwrap().unwrap();
            if p.icon.is_empty() {
                let _ = pico.class_list().add_1("term");
                pico.set_text_content(Some(">_"));
            } else {
                pico.set_inner_html(r#"<img alt="">"#);
                pico.query_selector("img").unwrap().unwrap().unchecked_into::<web_sys::HtmlImageElement>().set_src(&icon_url(p.icon));
            }
            b.query_selector(".pname").unwrap().unwrap().set_text_content(Some(p.name));
            listen(&b, "click", move |_| {
                let installed = INSTALLED.with(|x| x.borrow().clone());
                update(move |l| {
                    add_preset(l, &PRESETS[i], installed.as_deref(), new_id());
                })
            });
            presets.append_child(&b).unwrap();
        }
        // 點外面或 Esc 關閉
        let d: web_sys::EventTarget = doc().into();
        listen(&d, "mousedown", |e| {
            if !is_open() {
                return;
            }
            let inside = e
                .target()
                .and_then(|t| t.dyn_into::<web_sys::Node>().ok())
                .map(|n| el("apps").contains(Some(&n)) || el("apps-toggle").contains(Some(&n)))
                .unwrap_or(false);
            if !inside {
                set_open(false);
            }
        });
        listen(&d, "keydown", |e| {
            if is_open() && e.unchecked_ref::<KeyboardEvent>().key() == "Escape" {
                set_open(false);
            }
        });
    }
}

pub use view::{close, start};

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn entries() {
        let mut l = vec![];
        assert!(add(&mut l, "Safari", "app", "/Applications/Safari.app", "a".into()));
        assert!(!add(&mut l, "Safari 2", "app", "/Applications/Safari.app", "x".into())); // 重複
        assert!(add(&mut l, "VS Code", "url", "vscode://", "b".into()));
        assert!(!add(&mut l, "壞網址", "url", "javascript:alert(1)", "y".into()));
        assert!(!add(&mut l, "沒協定", "url", "vscode", "z".into()));
        assert!(!add(&mut l, "  ", "url", "slack://open", "w".into()));
        reorder(&mut l, "a", "b", true);
        assert_eq!(l.iter().map(|a| a.id.as_str()).collect::<Vec<_>>(), ["b", "a"]);
        remove(&mut l, "b");
        assert_eq!(l.len(), 1);
        assert!(valid_url("spotify:") && valid_url("https://x.com") && !valid_url("file:///etc/passwd"));
        assert_eq!(avatar("visual studio").0, "V");
        assert_eq!(avatar("備忘錄").0, "備");
        assert_eq!(avatar("Notion"), avatar("Notion"));
        let inst = |n: &str, p: &str| Installed { name: n.into(), path: p.into() };
        let list = vec![inst("Claude", "/Applications/Claude.app"), inst("Terminal", TERMINAL_MAC), inst("zoom.us", "/Applications/zoom.us.app")];
        let by = |n: &str| PRESETS.iter().find(|p| p.name == n).unwrap();
        assert_eq!(resolve_preset(by("Claude"), Some(&list)), ("app", "/Applications/Claude.app".to_string()));
        assert_eq!(resolve_preset(by("Claude"), None), ("url", "https://claude.ai/".to_string()));
        assert_eq!(resolve_preset(by("Zoom"), Some(&list)), ("app", "/Applications/zoom.us.app".to_string()));
        assert_eq!(resolve_preset(by("Terminal"), None), ("app", TERMINAL_MAC.to_string()));
        assert_eq!(resolve_preset(by("Google Meet"), Some(&list)).0, "url");
        assert_eq!(
            PRESETS.iter().map(|p| p.name).collect::<Vec<_>>(),
            ["Terminal", "Claude", "ChatGPT", "Gemini", "VS Code", "Obsidian", "Notion", "Discord", "Slack", "Google Meet", "Zoom", "Teams", "Spotify"]
        );
        let mut l2 = vec![];
        assert!(add_preset(&mut l2, by("Slack"), None, "s".into()));
        assert_eq!(l2[0].icon.as_deref(), Some("slack.com"));
        assert!(add_preset(&mut l2, by("Terminal"), None, "t".into()));
        assert!(l2[1].icon.is_none());
    }
}
