//! WatchLaterHub 電腦小幫手（Chrome Native Messaging host）
//!
//! Chrome 擴充功能不能直接開啟電腦上的程式，這個小程式由 Chrome 啟動，
//! 透過 stdin/stdout（4 位元組長度 + JSON）接收指令：
//!
//! - `{"action":"ping"}` → `{"ok":true,"version":1,"os":"macos"}`
//! - `{"action":"list"}` → `{"ok":true,"apps":[{"name":"Safari","path":"/Applications/Safari.app"}…]}`
//! - `{"action":"open","path":"…"}` → 開啟那個軟體
//!
//! 安全：只會開啟「已安裝軟體清單」裡的項目，不執行任何其他指令。

use serde::Serialize;
use serde_json::{json, Value};
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};
use std::process::Command;

#[derive(Serialize, Clone, Debug, PartialEq)]
struct App {
    name: String,
    path: String,
}

// ---------- 訊息格式 ----------

fn read_message(r: &mut impl Read) -> io::Result<Option<Value>> {
    let mut len = [0u8; 4];
    match r.read_exact(&mut len) {
        Ok(()) => {}
        Err(e) if e.kind() == io::ErrorKind::UnexpectedEof => return Ok(None),
        Err(e) => return Err(e),
    }
    let n = u32::from_le_bytes(len) as usize;
    if n > 1024 * 1024 {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "message too large"));
    }
    let mut buf = vec![0u8; n];
    r.read_exact(&mut buf)?;
    serde_json::from_slice(&buf).map(Some).map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))
}

fn write_message(w: &mut impl Write, v: &Value) -> io::Result<()> {
    let s = serde_json::to_vec(v)?;
    w.write_all(&(s.len() as u32).to_le_bytes())?;
    w.write_all(&s)?;
    w.flush()
}

// ---------- 已安裝軟體 ----------

fn home() -> PathBuf {
    std::env::var_os("HOME").map(PathBuf::from).unwrap_or_default()
}

#[cfg(target_os = "macos")]
fn list_apps() -> Vec<App> {
    let mut dirs = vec![
        PathBuf::from("/Applications"),
        PathBuf::from("/Applications/Utilities"),
        PathBuf::from("/System/Applications"),
        PathBuf::from("/System/Applications/Utilities"),
        home().join("Applications"),
    ];
    // /Applications 底下一層資料夾裡的 .app（例如 Microsoft Office 套件）
    if let Ok(rd) = std::fs::read_dir("/Applications") {
        for e in rd.flatten() {
            let p = e.path();
            if p.is_dir() && p.extension().is_none() {
                dirs.push(p);
            }
        }
    }
    let mut apps = vec![];
    for d in dirs {
        let Ok(rd) = std::fs::read_dir(&d) else { continue };
        for e in rd.flatten() {
            let p = e.path();
            if p.extension().and_then(|x| x.to_str()) == Some("app") {
                let name = p.file_stem().and_then(|x| x.to_str()).unwrap_or_default().to_string();
                apps.push(App { name, path: p.to_string_lossy().into_owned() });
            }
        }
    }
    finish(apps)
}

#[cfg(not(target_os = "macos"))]
fn list_apps() -> Vec<App> {
    // Linux：.desktop 檔
    let mut apps = vec![];
    for d in [PathBuf::from("/usr/share/applications"), PathBuf::from("/usr/local/share/applications"), home().join(".local/share/applications")] {
        let Ok(rd) = std::fs::read_dir(&d) else { continue };
        for e in rd.flatten() {
            let p = e.path();
            if p.extension().and_then(|x| x.to_str()) != Some("desktop") {
                continue;
            }
            let Ok(text) = std::fs::read_to_string(&p) else { continue };
            if desktop_field(&text, "NoDisplay").as_deref() == Some("true") || desktop_field(&text, "Exec").is_none() {
                continue;
            }
            if let Some(name) = desktop_field(&text, "Name") {
                apps.push(App { name, path: p.to_string_lossy().into_owned() });
            }
        }
    }
    finish(apps)
}

/// .desktop 檔裡 [Desktop Entry] 區段的欄位
#[cfg_attr(target_os = "macos", allow(dead_code))]
fn desktop_field(text: &str, key: &str) -> Option<String> {
    let mut in_entry = false;
    for line in text.lines() {
        let line = line.trim();
        if line.starts_with('[') {
            in_entry = line == "[Desktop Entry]";
            continue;
        }
        if in_entry {
            if let Some(v) = line.strip_prefix(key).and_then(|r| r.strip_prefix('=')) {
                return Some(v.trim().to_string());
            }
        }
    }
    None
}

/// 依名稱排序、去重
fn finish(mut apps: Vec<App>) -> Vec<App> {
    apps.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()).then(a.path.cmp(&b.path)));
    apps.dedup_by(|a, b| a.name == b.name);
    apps
}

// ---------- 開啟 ----------

#[cfg(target_os = "macos")]
fn launch(path: &Path) -> io::Result<()> {
    Command::new("/usr/bin/open").arg(path).spawn().map(|_| ())
}

#[cfg(not(target_os = "macos"))]
fn launch(path: &Path) -> io::Result<()> {
    let text = std::fs::read_to_string(path)?;
    let exec = desktop_field(&text, "Exec").ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "no Exec"))?;
    let args = exec_args(&exec);
    let (prog, rest) = args.split_first().ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "empty Exec"))?;
    Command::new(prog).args(rest).spawn().map(|_| ())
}

/// Exec 欄位拆成參數，去掉 %U %f 這類欄位代碼
#[cfg_attr(target_os = "macos", allow(dead_code))]
fn exec_args(exec: &str) -> Vec<String> {
    let mut out = vec![];
    let mut cur = String::new();
    let mut quoted = false;
    for c in exec.chars() {
        match c {
            '"' => quoted = !quoted,
            ' ' if !quoted => {
                if !cur.is_empty() {
                    out.push(std::mem::take(&mut cur));
                }
            }
            _ => cur.push(c),
        }
    }
    if !cur.is_empty() {
        out.push(cur);
    }
    out.into_iter().filter(|a| !(a.len() == 2 && a.starts_with('%'))).collect()
}

// ---------- 指令 ----------

fn handle(msg: &Value) -> Value {
    match msg["action"].as_str() {
        Some("ping") => json!({ "ok": true, "version": 1, "os": std::env::consts::OS }),
        Some("list") => json!({ "ok": true, "apps": list_apps() }),
        Some("open") => {
            let Some(path) = msg["path"].as_str() else { return json!({ "ok": false, "error": "缺少 path" }) };
            // 只開啟清單裡的軟體
            if !list_apps().iter().any(|a| a.path == path) {
                return json!({ "ok": false, "error": "找不到這個軟體（可能已移除）" });
            }
            match launch(Path::new(path)) {
                Ok(()) => json!({ "ok": true }),
                Err(e) => json!({ "ok": false, "error": e.to_string() }),
            }
        }
        _ => json!({ "ok": false, "error": "未知的指令" }),
    }
}

fn main() {
    let stdin = io::stdin();
    let stdout = io::stdout();
    let (mut r, mut w) = (stdin.lock(), stdout.lock());
    // sendNativeMessage 每次只送一則；connectNative 可能送很多則
    while let Ok(Some(msg)) = read_message(&mut r) {
        if write_message(&mut w, &handle(&msg)).is_err() {
            break;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn framing_round_trip() {
        let mut buf = vec![];
        write_message(&mut buf, &json!({"action": "ping"})).unwrap();
        assert_eq!(&buf[..4], &(17u32).to_le_bytes());
        let v = read_message(&mut &buf[..]).unwrap().unwrap();
        assert_eq!(v["action"], "ping");
        assert!(read_message(&mut &b""[..]).unwrap().is_none());
    }

    #[test]
    fn commands() {
        assert_eq!(handle(&json!({"action": "ping"}))["ok"], true);
        assert_eq!(handle(&json!({"action": "nope"}))["ok"], false);
        // 不在清單裡的路徑不會執行
        let r = handle(&json!({"action": "open", "path": "/bin/rm"}));
        assert_eq!(r["ok"], false);
    }

    #[test]
    fn desktop_parsing() {
        let t = "[Desktop Entry]\nName=Text Editor\nExec=gedit %U --new-window\n[Desktop Action x]\nName=Other\n";
        assert_eq!(desktop_field(t, "Name").as_deref(), Some("Text Editor"));
        assert_eq!(exec_args(&desktop_field(t, "Exec").unwrap()), ["gedit", "--new-window"]);
        assert_eq!(exec_args(r#""/opt/My App/app" --flag %f"#), ["/opt/My App/app", "--flag"]);
    }
}
