//! 「最近」：最近瀏覽的網頁清單（來自 Chrome 瀏覽紀錄），可拖曳排序、✕ 從清單移除
//!
//! 清單自己存一份：新瀏覽的網頁放到最上面，使用者可以拖曳調整順序或移除；
//! 移除只是從這個清單拿掉，不會刪 Chrome 的瀏覽紀錄。

use serde::{Deserialize, Serialize};

pub const KEY: &str = "recent";
pub const SYNC_KEY: &str = "recentSyncedAt";
pub const REMOVED_KEY: &str = "recentRemoved";
pub const MAX: usize = 30;

/// 使用者移除過的網頁：(網址, 當時的瀏覽時間)。之後重新瀏覽（時間更新）才會再出現
pub type Removed = Vec<(String, f64)>;

/// 記下被移除的項目（只留最近 200 筆）
pub fn remember_removed(removed: &mut Removed, items: &[Recent]) {
    for r in items {
        removed.retain(|(u, _)| u != &r.url);
        removed.push((r.url.clone(), r.at));
    }
    let n = removed.len();
    if n > 200 {
        removed.drain(..n - 200);
    }
}

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq)]
pub struct Recent {
    pub url: String,
    pub title: String,
    /// 最後瀏覽時間（毫秒時間戳）
    pub at: f64,
}

// ---------- 純邏輯（可在本機 cargo test） ----------

/// 要不要放進「最近」：只收一般網頁，略過新分頁、擴充功能頁面等
pub fn wanted(url: &str) -> bool {
    (url.starts_with("http://") || url.starts_with("https://") || url.starts_with("file://"))
        && !url.starts_with("https://www.google.com/_/chrome/newtab")
}

/// 加入新的瀏覽紀錄（`visits` 由舊到新）：已在清單的移到最上面並更新標題，新的插在最上面，最多保留 MAX 筆
pub fn apply_visits(list: &mut Vec<Recent>, visits: &[Recent], removed: &Removed) {
    let was_removed = |v: &Recent| removed.iter().any(|(u, at)| u == &v.url && *at >= v.at);
    for v in visits.iter().filter(|v| wanted(&v.url) && !was_removed(v)) {
        let title = match list.iter().position(|r| r.url == v.url) {
            // 已在清單、這次不是更新的瀏覽 → 保持原位（不打亂使用者排的順序），只補上剛載入的標題
            Some(i) if list[i].at >= v.at => {
                if list[i].title.trim().is_empty() && !v.title.trim().is_empty() {
                    list[i].title = v.title.clone();
                }
                continue;
            }
            Some(i) => {
                let old = list.remove(i);
                if v.title.trim().is_empty() { old.title } else { v.title.clone() }
            }
            None => v.title.clone(),
        };
        list.insert(0, Recent { url: v.url.clone(), title, at: v.at });
    }
    list.truncate(MAX);
}

pub fn remove(list: &mut Vec<Recent>, url: &str) {
    list.retain(|r| r.url != url);
}

pub fn reorder(list: &mut Vec<Recent>, from: &str, to: &str, after: bool) {
    crate::videos::move_by_key(list, |r| r.url.as_str(), from, to, after);
}

/// 網址的網域（顯示用）
pub fn host_of(url: &str) -> String {
    url::Url::parse(url)
        .ok()
        .and_then(|u| u.host_str().map(|h| h.trim_start_matches("www.").to_string()))
        .unwrap_or_default()
}

// ---------- 畫面 ----------

mod view {
    use super::*;
    use crate::chrome::{self, to_js};
    use crate::drag::{Pos, Sortable};
    use crate::ui::{doc, el, hide, listen, on_click, spawn};
    use crate::videos::ago;
    use std::cell::Cell;
    use std::rc::Rc;
    use wasm_bindgen::prelude::*;
    use wasm_bindgen::JsCast;
    use web_sys::KeyboardEvent;

    thread_local! {
        static SYNCING: Cell<bool> = const { Cell::new(false) };
    }

    async fn load() -> Vec<Recent> {
        chrome::get_or(KEY, vec![]).await
    }

    async fn save(list: &[Recent]) {
        chrome::set(&[(KEY, to_js(list))]).await;
    }

    /// 把上次同步之後的瀏覽紀錄併進清單
    async fn sync() -> Vec<Recent> {
        let mut list = load().await;
        if SYNCING.with(|s| s.replace(true)) {
            return list;
        }
        let since: f64 = chrome::get_or(SYNC_KEY, 0.0).await;
        // 第一次：抓最近 7 天
        // 往回多抓 1 分鐘，補上剛才還沒載入完的標題
        let start = if since > 0.0 { since - 60_000.0 } else { chrome::now() - 7.0 * 86_400_000.0 };
        let mut items = chrome::history_since(start, 200).await;
        items.sort_by(|a, b| a.last_visit.total_cmp(&b.last_visit));
        let visits: Vec<Recent> =
            items.into_iter().map(|h| Recent { url: h.url, title: h.title, at: h.last_visit }).collect();
        let newest = visits.last().map(|v| v.at).unwrap_or(since);
        if !visits.is_empty() {
            let removed: Removed = chrome::get_or(REMOVED_KEY, vec![]).await;
            apply_visits(&mut list, &visits, &removed);
            save(&list).await;
        }
        chrome::set(&[(SYNC_KEY, to_js(&newest.max(since)))]).await;
        SYNCING.with(|s| s.set(false));
        list
    }

    fn update(f: impl FnOnce(&mut Vec<Recent>) + 'static) {
        spawn(async move {
            let mut list = load().await;
            let before = list.clone();
            f(&mut list);
            // 被拿掉的項目記下來，避免下次同步又加回來
            let gone: Vec<Recent> = before.into_iter().filter(|b| !list.iter().any(|r| r.url == b.url)).collect();
            if !gone.is_empty() {
                let mut removed: Removed = chrome::get_or(REMOVED_KEY, vec![]).await;
                remember_removed(&mut removed, &gone);
                chrome::set(&[(REMOVED_KEY, to_js(&removed))]).await;
            }
            save(&list).await;
            render(&list);
        });
    }

    fn render(list: &[Recent]) {
        let ul = el("recent-list");
        ul.set_inner_html("");
        if list.is_empty() {
            ul.set_inner_html(r#"<li class="todo-none">還沒有瀏覽紀錄</li>"#);
            return;
        }
        let q = crate::ui::search_text("recent-search");
        let shown: Vec<&Recent> = list.iter().filter(|r| crate::videos::matches(&q, &[&r.title, &r.url])).collect();
        if shown.is_empty() {
            ul.set_inner_html(r#"<li class="todo-none">找不到符合的網頁</li>"#);
            return;
        }
        let now = chrome::now();
        for r in shown {
            let label = if r.title.trim().is_empty() { r.url.as_str() } else { r.title.as_str() };
            let li = doc().create_element("li").unwrap();
            li.set_class_name("bm-row recent-row");
            li.append_child(&crate::drag::grip()).unwrap();
            let a = crate::bookmarks::link_anchor(&r.url, label);
            let meta = doc().create_element("small").unwrap();
            meta.set_class_name("recent-meta");
            let host = host_of(&r.url);
            let when = ago((now - r.at) / 60_000.0);
            meta.set_text_content(Some(&if host.is_empty() { when } else { format!("{host} · {when}") }));
            a.append_child(&meta).unwrap();
            li.append_child(&a).unwrap();

            let x = doc().create_element("button").unwrap();
            x.set_class_name("bm-del");
            x.set_text_content(Some("✕"));
            let _ = x.set_attribute("type", "button");
            let _ = x.set_attribute("title", "從清單移除（不會刪除瀏覽紀錄）");
            let _ = x.set_attribute("aria-label", &format!("從最近移除：{label}"));
            let url = r.url.clone();
            listen(&x, "click", move |e| {
                e.prevent_default();
                e.stop_propagation();
                let url = url.clone();
                update(move |l| remove(l, &url));
            });
            li.append_child(&x).unwrap();

            crate::drag::sortable(
                Sortable { item: li.clone(), handle: Some(li.clone()), zone: li.clone(), group: "recent", id: r.url.clone(), can_contain: false },
                Rc::new(|from, to, pos| update(move |l| reorder(l, &from, &to, pos == Pos::After))),
            );
            ul.append_child(&li).unwrap();
        }
    }

    fn is_open() -> bool {
        !el("recent").hidden()
    }

    fn set_open(open: bool) {
        hide("recent", !open);
        let _ = el("recent-toggle").class_list().toggle_with_force("on", open);
        let _ = el("recent-toggle").set_attribute("aria-expanded", if open { "true" } else { "false" });
        if open {
            let _ = el("recent-search").focus();
            spawn(async { render(&sync().await) });
        }
    }

    pub fn start() {
        on_click("recent-toggle", || set_open(!is_open()));
        on_click("recent-close", || set_open(false));
        on_click("recent-clear", || update(|l| l.clear()));
        crate::ui::search_box("recent-search", || spawn(async { render(&load().await) }));

        let d: web_sys::EventTarget = doc().into();
        listen(&d, "mousedown", |e| {
            if !is_open() {
                return;
            }
            let inside = e
                .target()
                .and_then(|t| t.dyn_into::<web_sys::Node>().ok())
                .map(|n| el("recent").contains(Some(&n)) || el("recent-toggle").contains(Some(&n)))
                .unwrap_or(false);
            if !inside {
                set_open(false);
            }
        });
        listen(&d, "keydown", |e| {
            if is_open() && e.unchecked_ref::<KeyboardEvent>().key() == "Escape" {
                set_open(false);
                let _ = el("recent-toggle").focus();
            }
        });

        // 開著的時候有新的瀏覽就更新（等一下讓網頁標題載入）
        chrome::on_history_visited(|| {
            for ms in [300, 2500] {
                crate::ui::timeout(ms, || {
                    if is_open() {
                        spawn(async { render(&sync().await) });
                    }
                });
            }
        });
        // 其他分頁改了清單
        let cb = Closure::<dyn FnMut(JsValue, JsValue)>::new(|changes: JsValue, _area: JsValue| {
            if is_open()
                && js_sys::Reflect::has(&changes, &KEY.into()).unwrap_or(false)
                && doc().query_selector("#recent-list .dragging").ok().flatten().is_none()
            {
                spawn(async { render(&load().await) });
            }
        });
        chrome::on_storage_changed(&cb);
        cb.forget();

        // 背景先同步一次，打開時就是新的
        spawn(async {
            sync().await;
        });
    }
}

pub use view::start;

#[cfg(test)]
mod tests {
    use super::*;

    fn r(url: &str, title: &str, at: f64) -> Recent {
        Recent { url: url.into(), title: title.into(), at }
    }
    fn urls(l: &[Recent]) -> String {
        l.iter().map(|x| x.url.trim_start_matches("https://")).collect::<Vec<_>>().join(",")
    }

    #[test]
    fn visits_and_edits() {
        let none: Removed = vec![];
        let mut l = vec![];
        apply_visits(&mut l, &[r("https://a", "A", 1.0), r("chrome://settings", "S", 2.0), r("https://b", "B", 3.0)], &none);
        assert_eq!(urls(&l), "b,a");
        // 使用者調整順序、移除
        reorder(&mut l, "https://b", "https://a", true);
        assert_eq!(urls(&l), "a,b");
        // 再次瀏覽 b（較新）→ 移到最上面；標題空白時保留舊標題
        apply_visits(&mut l, &[r("https://b", "", 5.0), r("https://c", "C", 6.0)], &none);
        assert_eq!(urls(&l), "c,b,a");
        assert_eq!(l[1].title, "B");
        // 同一次瀏覽、標題後來才載入 → 補上標題但不移動
        apply_visits(&mut l, &[r("https://q", "", 7.0)], &none);
        apply_visits(&mut l, &[r("https://c", "C2", 6.0), r("https://q", "Q", 7.0)], &none);
        assert_eq!(urls(&l), "q,c,b,a");
        assert_eq!((l[0].title.as_str(), l[1].title.as_str()), ("Q", "C"));
        remove(&mut l, "https://q");
        assert_eq!(l[1].at, 5.0);
        // 舊的紀錄不會打亂順序
        apply_visits(&mut l, &[r("https://a", "A", 1.0)], &none);
        assert_eq!(urls(&l), "c,b,a");
        remove(&mut l, "https://c");
        assert_eq!(urls(&l), "b,a");
        // 上限
        let many: Vec<_> = (0..40).map(|i| r(&format!("https://x{i}"), "x", 10.0 + i as f64)).collect();
        apply_visits(&mut l, &many, &none);
        assert_eq!(l.len(), MAX);
        assert_eq!(l[0].url, "https://x39");
        assert_eq!(host_of("https://www.youtube.com/watch?v=1"), "youtube.com");

        // 移除過的：同一次瀏覽不再加回，重新瀏覽才會出現
        let mut l = vec![r("https://a", "A", 1.0)];
        let mut removed = vec![];
        remember_removed(&mut removed, &l);
        remove(&mut l, "https://a");
        apply_visits(&mut l, &[r("https://a", "A", 1.0)], &removed);
        assert!(l.is_empty());
        apply_visits(&mut l, &[r("https://a", "A", 2.0)], &removed);
        assert_eq!(urls(&l), "a");
    }
}
