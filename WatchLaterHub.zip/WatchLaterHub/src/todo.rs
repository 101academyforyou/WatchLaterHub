//! TODO 清單：頂列「TODO」按鈕打開的下拉清單，存在 chrome.storage

use serde::{Deserialize, Serialize};

pub const KEY: &str = "todos";

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq)]
pub struct Todo {
    pub id: String,
    pub text: String,
    #[serde(default)]
    pub done: bool,
}

// ---------- 純邏輯（可在本機 cargo test） ----------

/// 新增一項（空白不加）。回傳是否有加入
pub fn add(list: &mut Vec<Todo>, text: &str, id: String) -> bool {
    let text = text.trim();
    if text.is_empty() {
        return false;
    }
    list.push(Todo { id, text: text.to_string(), done: false });
    true
}

pub fn toggle(list: &mut [Todo], id: &str) {
    if let Some(t) = list.iter_mut().find(|t| t.id == id) {
        t.done = !t.done;
    }
}

/// 改文字；改成空白就刪除
pub fn edit(list: &mut Vec<Todo>, id: &str, text: &str) {
    let text = text.trim();
    if text.is_empty() {
        return remove(list, id);
    }
    if let Some(t) = list.iter_mut().find(|t| t.id == id) {
        t.text = text.to_string();
    }
}

pub fn remove(list: &mut Vec<Todo>, id: &str) {
    list.retain(|t| t.id != id);
}

pub fn clear_done(list: &mut Vec<Todo>) {
    list.retain(|t| !t.done);
}

pub fn remaining(list: &[Todo]) -> usize {
    list.iter().filter(|t| !t.done).count()
}

/// 顯示順序：未完成在前、已完成在後，各自維持加入順序
pub fn ordered(list: &[Todo]) -> Vec<&Todo> {
    list.iter().filter(|t| !t.done).chain(list.iter().filter(|t| t.done)).collect()
}

// ---------- 畫面 ----------

mod view {
    use super::*;
    use crate::chrome::{self, to_js};
    use crate::ui::{doc, el, hide, listen, on_click, spawn};
    use wasm_bindgen::prelude::*;
    use wasm_bindgen::JsCast;
    use web_sys::{Element, HtmlButtonElement, HtmlInputElement, KeyboardEvent};

    async fn load() -> Vec<Todo> {
        chrome::get_or(KEY, vec![]).await
    }

    async fn save(list: &[Todo]) {
        chrome::set(&[(KEY, to_js(list))]).await;
    }

    /// 讀出 → 修改 → 存回 → 重畫
    fn update(f: impl FnOnce(&mut Vec<Todo>) + 'static) {
        spawn(async move {
            let mut list = load().await;
            f(&mut list);
            save(&list).await;
            render_list(&list);
        });
    }

    fn new_id() -> String {
        format!("{:x}{:04x}", chrome::now() as u64, (js_sys::Math::random() * 65536.0) as u32)
    }

    fn input(id: &str) -> HtmlInputElement {
        el(id).unchecked_into()
    }

    fn render_list(list: &[Todo]) {
        let n = remaining(list);
        el("todo-count").set_text_content(Some(&if n > 0 { format!("({n})") } else { String::new() }));
        let done = list.len() - n;
        el("todo-summary").set_text_content(Some(&if list.is_empty() {
            String::new()
        } else {
            format!("剩 {n} 項 · 已完成 {done} 項")
        }));
        el("todo-clear").unchecked_into::<HtmlButtonElement>().set_disabled(done == 0);
        hide("todo-foot", list.is_empty());

        let ul = el("todo-list");
        ul.set_inner_html("");
        if list.is_empty() {
            ul.set_inner_html(r#"<li class="todo-none">還沒有待辦事項，在上面輸入後按 Enter</li>"#);
            return;
        }
        for t in ordered(list) {
            ul.append_child(&make_item(t)).unwrap();
        }
    }

    fn make_item(t: &Todo) -> Element {
        let li = doc().create_element("li").unwrap();
        li.set_class_name(if t.done { "todo-item done" } else { "todo-item" });
        li.set_inner_html(
            r#"<input type="checkbox"><span class="todo-text" title="點兩下編輯"></span><button class="bm-del" type="button" title="刪除">✕</button>"#,
        );
        let cb: HtmlInputElement = li.query_selector("input").unwrap().unwrap().unchecked_into();
        cb.set_checked(t.done);
        let _ = cb.set_attribute("aria-label", &format!("完成：{}", t.text));
        let span = li.query_selector(".todo-text").unwrap().unwrap();
        span.set_text_content(Some(&t.text));

        let id = t.id.clone();
        listen(&cb, "change", move |_| {
            let id = id.clone();
            update(move |l| toggle(l, &id));
        });
        let id = t.id.clone();
        listen(&li.query_selector("button").unwrap().unwrap(), "click", move |_| {
            let id = id.clone();
            update(move |l| remove(l, &id));
        });
        let (id, text, span2) = (t.id.clone(), t.text.clone(), span.clone());
        listen(&span, "dblclick", move |_| start_edit(&span2, id.clone(), text.clone()));
        li
    }

    /// 點兩下文字：原地改成輸入框；Enter 或離開儲存、Esc 取消
    fn start_edit(span: &Element, id: String, text: String) {
        let inp: HtmlInputElement = doc().create_element("input").unwrap().unchecked_into();
        inp.set_class_name("todo-edit");
        inp.set_value(&text);
        let _ = span.replace_with_with_node_1(&inp);
        let _ = inp.focus();
        inp.select();

        let finished = std::rc::Rc::new(std::cell::Cell::new(false));
        let (f1, i1, id1) = (finished.clone(), inp.clone(), id.clone());
        listen(&inp, "keydown", move |e| {
            let k: &KeyboardEvent = e.unchecked_ref();
            if k.is_composing() {
                return;
            }
            match k.key().as_str() {
                "Enter" => {
                    f1.set(true);
                    let (id, v) = (id1.clone(), i1.value());
                    update(move |l| edit(l, &id, &v));
                }
                "Escape" => {
                    e.stop_propagation(); // 不要順便關掉整個清單
                    f1.set(true);
                    spawn(async { render_list(&load().await) });
                }
                _ => {}
            }
        });
        let i2 = inp.clone();
        listen(&inp, "blur", move |_| {
            if !finished.get() {
                finished.set(true);
                let (id, v) = (id.clone(), i2.value());
                update(move |l| edit(l, &id, &v));
            }
        });
    }

    fn is_open() -> bool {
        !el("todo").hidden()
    }

    fn set_open(open: bool) {
        hide("todo", !open);
        let _ = el("todo-toggle").class_list().toggle_with_force("on", open);
        let _ = el("todo-toggle").set_attribute("aria-expanded", if open { "true" } else { "false" });
        if open {
            let _ = el("todo-input").focus();
        }
    }

    fn add_from_input() {
        let v = input("todo-input").value();
        if v.trim().is_empty() {
            return;
        }
        input("todo-input").set_value("");
        update(move |l| {
            add(l, &v, new_id());
        });
    }

    pub fn start() {
        on_click("todo-toggle", || set_open(!is_open()));
        on_click("todo-close", || set_open(false));
        on_click("todo-add", add_from_input);
        on_click("todo-clear", || update(clear_done));
        listen(&el("todo-input"), "keydown", |e| {
            let k: &KeyboardEvent = e.unchecked_ref();
            if k.key() == "Enter" && !k.is_composing() {
                e.prevent_default();
                add_from_input();
            }
        });

        // 點清單外面或按 Esc 關閉
        let d: web_sys::EventTarget = doc().into();
        listen(&d, "mousedown", |e| {
            if !is_open() {
                return;
            }
            let inside = e
                .target()
                .and_then(|t| t.dyn_into::<web_sys::Node>().ok())
                .map(|n| el("todo").contains(Some(&n)) || el("todo-toggle").contains(Some(&n)))
                .unwrap_or(false);
            if !inside {
                set_open(false);
            }
        });
        listen(&d, "keydown", |e| {
            if is_open() && e.unchecked_ref::<KeyboardEvent>().key() == "Escape" {
                set_open(false);
                let _ = el("todo-toggle").focus();
            }
        });

        // 其他分頁改了清單時同步更新（正在編輯時不打斷）
        let cb = Closure::<dyn FnMut(JsValue, JsValue)>::new(|changes: JsValue, _area: JsValue| {
            if js_sys::Reflect::has(&changes, &KEY.into()).unwrap_or(false)
                && doc().query_selector("#todo-list .todo-edit").ok().flatten().is_none()
            {
                spawn(async { render_list(&load().await) });
            }
        });
        chrome::on_storage_changed(&cb);
        cb.forget();

        spawn(async { render_list(&load().await) });
    }
}

pub use view::start;

#[cfg(test)]
mod tests {
    use super::*;

    fn ids(v: &[&Todo]) -> Vec<String> {
        v.iter().map(|t| t.id.clone()).collect()
    }

    #[test]
    fn add_toggle_edit_remove() {
        let mut l = vec![];
        assert!(add(&mut l, "  買牛奶 ", "a".into()));
        assert!(!add(&mut l, "   ", "x".into()));
        add(&mut l, "寫論文", "b".into());
        add(&mut l, "回信", "c".into());
        assert_eq!(l[0].text, "買牛奶");
        assert_eq!(remaining(&l), 3);

        toggle(&mut l, "a");
        assert_eq!(remaining(&l), 2);
        assert_eq!(ids(&ordered(&l)), ["b", "c", "a"]);

        edit(&mut l, "b", " 寫論文第三章 ");
        assert_eq!(l[1].text, "寫論文第三章");
        edit(&mut l, "c", "  ");
        assert_eq!(l.len(), 2);

        clear_done(&mut l);
        assert_eq!(ids(&ordered(&l)), ["b"]);
        remove(&mut l, "b");
        assert!(l.is_empty());
    }
}
