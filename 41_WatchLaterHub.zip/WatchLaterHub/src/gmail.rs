//! 用使用者自己的 Gmail 寄信給自己（TODO 提醒的寄信通知）
//!
//! 只要求 `gmail.send` 權限：只能寄信，不能讀信。

use crate::chrome::{self, to_js, R};
use crate::youtube::{oauth_token, AUTH_LOST};
use base64::engine::general_purpose::{STANDARD, URL_SAFE_NO_PAD};
use base64::Engine;

const SCOPES: &str = "https://www.googleapis.com/auth/gmail.send email";
const TOKEN_KEY: &str = "gmToken";
const EMAIL_KEY: &str = "gmEmail";
const SEND_URL: &str = "https://gmail.googleapis.com/gmail/v1/users/me/messages/send";

// ---------- 純邏輯（可在本機 cargo test） ----------

/// 非 ASCII 的信件標頭用 RFC 2047 編碼
fn encode_header(s: &str) -> String {
    if s.is_ascii() {
        s.to_string()
    } else {
        format!("=?UTF-8?B?{}?=", STANDARD.encode(s))
    }
}

/// 組出 Gmail API 要的 raw 信件（RFC 2822，base64url）
pub fn build_raw(to: &str, subject: &str, body: &str) -> String {
    let body_b64 = STANDARD.encode(body.replace('\n', "\r\n"));
    // 每行最多 76 字元
    let wrapped: Vec<&str> = body_b64.as_bytes().chunks(76).map(|c| std::str::from_utf8(c).unwrap()).collect();
    let msg = format!(
        "To: {to}\r\nFrom: {to}\r\nSubject: {}\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n{}\r\n",
        encode_header(subject),
        wrapped.join("\r\n")
    );
    URL_SAFE_NO_PAD.encode(msg)
}

// ---------- 帳號 ----------

/// 已授權寄信的 Gmail 帳號
pub async fn email() -> Option<String> {
    chrome::get::<String>(EMAIL_KEY).await.filter(|e| !e.is_empty())
}

/// 跳出 Google 帳號選擇畫面，授權「代你寄信」，回傳帳號 email
pub async fn connect() -> R<String> {
    let token = oauth_token(SCOPES, TOKEN_KEY, EMAIL_KEY, true).await?;
    let r = chrome::fetch("https://www.googleapis.com/oauth2/v3/userinfo", Some(&token), "GET").await?;
    let email = r.json["email"].as_str().unwrap_or_default().to_string();
    if email.is_empty() {
        return Err("讀不到 Gmail 帳號".into());
    }
    chrome::set(&[(EMAIL_KEY, to_js(&email))]).await;
    Ok(email)
}

/// 寄信給自己；token 過期時在背景靜默換新（不跳視窗）
pub async fn send_to_self(subject: &str, body: &str) -> R<()> {
    let to = email().await.ok_or("尚未連結 Gmail 帳號")?;
    let raw = serde_json::json!({ "raw": build_raw(&to, subject, body) });
    let mut token = oauth_token(SCOPES, TOKEN_KEY, EMAIL_KEY, false).await?;
    for attempt in 0..2 {
        let r = chrome::fetch_post_json(SEND_URL, &token, &raw).await?;
        if r.status == 401 && attempt == 0 {
            chrome::remove(&[TOKEN_KEY]).await;
            token = oauth_token(SCOPES, TOKEN_KEY, EMAIL_KEY, false).await?;
            continue;
        }
        if r.status >= 400 {
            let msg = r.json["error"]["message"].as_str().unwrap_or("寄信失敗").to_string();
            return Err(if r.status == 403 && msg.contains("has not been used") {
                "Gmail API 尚未啟用（Google Cloud 專案要先啟用 Gmail API）".into()
            } else {
                format!("Gmail 錯誤 {}：{msg}", r.status)
            });
        }
        return Ok(());
    }
    Err(AUTH_LOST.into())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn raw_message() {
        let raw = build_raw("me@gmail.com", "⏰ TODO 提醒：交報告", "第一行\n第二行");
        let msg = String::from_utf8(URL_SAFE_NO_PAD.decode(raw).unwrap()).unwrap();
        assert!(msg.starts_with("To: me@gmail.com\r\nFrom: me@gmail.com\r\n"));
        // 中文主旨要編碼，解回來要一樣
        let subj = msg.lines().find(|l| l.starts_with("Subject: ")).unwrap();
        let b64 = subj.trim_start_matches("Subject: =?UTF-8?B?").trim_end_matches("?=");
        assert_eq!(String::from_utf8(STANDARD.decode(b64).unwrap()).unwrap(), "⏰ TODO 提醒：交報告");
        let body_b64: String = msg.split("\r\n\r\n").nth(1).unwrap().split_whitespace().collect();
        assert_eq!(String::from_utf8(STANDARD.decode(body_b64).unwrap()).unwrap(), "第一行\r\n第二行");
        assert_eq!(encode_header("Hello"), "Hello");
    }
}
